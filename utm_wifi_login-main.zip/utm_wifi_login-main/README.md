
## install dependencies
          pip install -r  requirements.txt          
         
## build  executable file
          pyinstaller --onefile main.py

## License
[![License: MIT](https://img.shields.io/badge/License-BSD%203--Clause-blue.svg)](https://github.com/chunkeat99/utm_wifi_login/blob/main/LICENSE)

